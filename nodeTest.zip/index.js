var express = require('express');
var bodyParser = require('body-parser');
var routes = require('./routes');
var checkSession = require('./helpers').checkSession;
var cleanSession = require('./helpers').cleanSession;

// start server without session
cleanSession();

var port = process.env.PORT || 8080;
var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));

// check session
app.use(checkSession);

// Serve html static file
app.use(express.static(__dirname + '/static/'));

// auth only endpoints

// api routes
routes(app);

app.listen(port);

