var users = require('./users');
var orders = require('./orders');
var newOrders = require('./newOrders');
var products = require('./products');
var customers = require('./customers');
var fs = require('fs');

function getProductId(productName) {
    product =  products.find(function(product) {
        return (product.name === productName);
    })

    return product.productId;
}

function getShippingAddress(customerName) {
    customer =  customers.find(function(customer) {
        return (customer.name === customerName);
    })

    return customer.address;
}

function addItemsCollection(item,quantity) {
    items = [];
    item = [].concat(item);
    quantity = [].concat(quantity);

    item.forEach(function(itm, idx) {
        itemObj = {
            item: itm,
            quantity: quantity[idx] === ''? 0 : quantity[idx]
        };
        items = items.concat(itemObj);
    })

    return items;
}

function storeSession(user) {
    fs.writeFile('session.json', JSON.stringify(user), 'utf8', function(err) {
        if(err) throw new Error('Session not stored');
    });
}

function isRestricted(url) {
    var unrestrictedEnpoints = ['/', '/login.html', '/auth'];
    var isUnrestricted = unrestrictedEnpoints.find(function(enpoint) {
        return enpoint === url;
    })

    if(!isUnrestricted)
        return true;

    return false;
}

module.exports = {
    auth: function(credentials) {
        user =  users.find(function(user) {
            return (user.username === credentials.username && user.password === credentials.password);
        })

        if(user)
            storeSession(user);

        return user;
    },
    parseOrder: function(order) {
        var parsedOrder = [];
        // handle FORMS
        if(order.item) {
            order.items = addItemsCollection(order.item, order.quantity);
        }

        order.items.forEach(function(item) {
            buyer = order.buyer;
            productId = getProductId(item.item);
            quantity = item.quantity;
            shippingAddress = getShippingAddress(buyer);
            shippingTarget = new Date(order.shippingDate + ' ' + order.shippingTime + ' GMT+00:00').getTime();

            parsedOrder.push({
                'buyer' : buyer,
                'productId' : productId,
                'quantity' : quantity,
                'shippingAddress' : shippingAddress,
                'shippingTarget' : shippingTarget
            })
        })
        
        return parsedOrder;
    },
    getAllOrders: function() {
        var allOrders = newOrders;
        orders.forEach(function(order) {
            allOrders = allOrders.concat(module.exports.parseOrder(order));
        })

        return allOrders;
    },
    filterOrders: function(query, allOrders) {
        var filterAttr = Object.keys(query);
        var filterValue = query[filterAttr];

        var filteredOrders = allOrders.filter(function(order) {
            return order[filterAttr] == filterValue;
        })

        return filteredOrders;
    },
    storeOrder: function(order) {
        var orders = newOrders;       
        var ordersToStore = orders.concat(order);

        fs.writeFile('newOrders.json', JSON.stringify(ordersToStore), 'utf8', function(err) {
            if(err) throw new Error('Order not stored');
        });
    },
    checkSession: function(req, res, next) {
        var restricted = isRestricted(req.url);
         fs.readFile('session.json', 'utf-8', function(err, user) {
            if(err) throw new Error('couldn\'t read session file');

            if ((restricted && user) || !restricted)
                return next();
            
            return res.redirect('/login.html');
        })
    },
    cleanSession: function() {
         fs.writeFile('session.json', '', 'utf8', function(err) {
            if(err) throw new Error('Session not cleaned');
        });
    }
}