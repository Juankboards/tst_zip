var helpers = require('./helpers');

var auth = helpers.auth;
var getAllOrders =helpers.getAllOrders;
var parseOrder = helpers.parseOrder;
var filterOrders = helpers.filterOrders;
var storeOrder = helpers.storeOrder;

module.exports = function(app) {
    //  Authorization endpoint
    app.post('/auth', function(req, res) {
        credentials = req.body;
        user = auth(credentials);

        if(!user){
            res.redirect('/');
        }else {
            res.redirect('/home.html');
        }
    })

    app.get('/show', function(req, res) {    
        res.json(getAllOrders());
    })

    app.post('/upload', function(req, res) {
        var order = req.body;
        parsedOrder = parseOrder(order);

        storeOrder(parsedOrder);
        
        res.redirect('/show.html');
    })

    app.get('/search', function(req, res) {
        var query = req.query;
        var allOrders = getAllOrders();

        var filteredOrders = filterOrders(query, allOrders) || [];

        res.json(filteredOrders);
    })
};